python convnet.py --data-path=/mnt/sdbmmt/yuyinan/plant/batches/ --save-path=./ --train-range=1-19 --test-range=20 --layer-def=./example-layers/plant-full.cfg --layer-params=./example-layers/params-plant-full.cfg --data-provider=cifar --test-freq=19 --epochs=200 --gpu=0 --crop-border=16 --whiten=none

