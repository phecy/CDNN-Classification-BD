# Copyright (c) 2013, Yinan Yu (yuyinan@baidu.com)
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
# - Redistributions of source code must retain the above copyright notice,
#   this list of conditions and the following disclaimer.
#
# - Redistributions in binary form must reproduce the above copyright notice,
#   this list of conditions and the following disclaimer in the documentation
#   and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import numpy
import zipfile
import os
import cPickle
import re
from scipy.misc import imread
from scipy.misc import imresize



def pickle(filename, data, compress=False):
    if compress:
        fo = zipfile.ZipFile(filename, 'w', zipfile.ZIP_DEFLATED, allowZip64=True)
        fo.writestr('data', cPickle.dumps(data, -1))
    else:
        fo = open(filename, "w")
        cPickle.dump(data, fo, protocol=cPickle.HIGHEST_PROTOCOL)

    fo.close()

def unpickle(filename):
    if not os.path.exists(filename):
        raise UnpickleError("Path '%s' does not exist." % filename)

    fo = open(filename, 'rb')
    dict = cPickle.load(fo)

    fo.close()
    return dict

import sys
if __name__ == '__main__':
    rank = int(sys.argv[1])
    imsz = int(sys.argv[2])
    psize = int(sys.argv[3])
    savepath = sys.argv[4]
    print rank, imsz, psize, savepath
    fo = open('train_list','r')
    lists = fo.readlines()
    lists = lists[rank*psize:(rank+1)*psize]
    if len(lists) == 0:
        exit(-1)

    fo.close();
    fo = open('ground_truth','r')
    gt = fo.readlines()
    gt = gt[rank*psize:(rank+1)*psize]
    fo.close()
    fo = open('label','r')
    labels = fo.readlines()
    fo.close()
    dic = {}
    for i,lab in enumerate(labels):
        dic[lab] = i
    data = numpy.zeros((imsz**2*3, psize), dtype='uint8')
    label = []
    filenames = []
    k = 0
    for i, fim in enumerate(lists):
        fim = fim[:-1]
        # load image
        try:
            im = imread(fim)
        except:
            print 'error image', fim
            continue
        if len(im.shape)==0:
            print 'error image', fim
            continue
        # resize image
        im = imresize(im, [imsz,imsz])
        if im.ndim == 2:
            im = im.reshape(imsz, imsz, 1)
            im = numpy.concatenate((im,im,im), axis=2)
        if im.shape[2] > 3:
            im = im[:,:,:3]
        # row first, col second and color third
        im = im.transpose(2, 0, 1)
        # reshape to vector
        im = im.reshape(-1, 1)
        # add to data list
        data[:,k] = im[:,0]
        k += 1
        # get image label
        label.append(dic[gt[i]])
        # get image name
        filenames.append(fim)
        # calculate data_mean
        if (i % 100) == 0:
            print i
    data = data[:,0:k]
    assert(data.shape[1] == len(label))
    #subdata = numpy.array(data, dtype='uint8')
    # remove dimension with 1 dims
    #subdata = subdata.squeeze()
    # change first dimension to number of cases
    #subdata = subdata.transpose()
    # prepare output batch
    output = {}
    output['labels'] = label
    output['data'] = data
    output['filenames'] = filenames
    output['batch_label'] = 'train batch ' + str(rank + 1)
    outputpath = os.path.join(savepath + '/data_batch_' + str(rank+1))
    pickle(outputpath, output)

