
#ifndef CONV_UTIL_H_
#define	CONV_UTIL_H_

#include "matrix.h"

void convFilterActsUnroll(Matrix& images, Matrix& filters, Matrix& targetss, int *offsetIn, int *offsetOut,
        int imgSizeX, int numModulesX, int paddingStart, int moduleStridei,
        int numImgColors, float scaletargetss, float scaleOutput);

void convLocalPoolMax(Matrix& images, Matrix& targets, int numFilters,
                   int subsX, int startX, int strideX, int outputsX);

void convLocalPoolAvg(Matrix& images, Matrix& targets, int numFilters,
                   int subsX, int startX, int strideX, int outputsX);

void convContrastNorm(Matrix& images, Matrix& meanDiffs, 
        Matrix& targets, int numFilters, int sizeX, float addScale, float powScale);

void convResponseNorm(Matrix& images, Matrix& targets, int numFilters, int sizeX, float addScale, float powScale);

void convContrastNormCrossMap(Matrix& images, Matrix& meanDiffs, 
                    Matrix& targets, int numFilters, int sizeF, float addScale, float powScale);

void convResponseNormCrossMap(Matrix& images, Matrix& targets, int numFilters, int sizeF, float addScale, float powScale);

void convAddBiases(Matrix& biases, Matrix& targets, int numModules, bool sharedBiases);

void fcAddBiases(Matrix& biases, Matrix& targets);

#endif	/* CONV_UTIL_H_ */

