
#ifndef CDNNSCORE_H_
#define	CDNNSCORE_H_

int initModel(const char *filePath);

int cnnScore(float *data, int dataNum, int dataDim, float *probs);

int releaseModel();

int getDataDim();

int getLabelsDim();


#endif	/* CDNNSCORE_H_ */

