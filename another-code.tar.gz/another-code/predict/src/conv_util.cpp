
#include <malloc.h>
#include <xmmintrin.h>
#include <assert.h>
extern "C" {
#include <cblas.h>
}
#include "matrix.h"
#include "conv_util.h"

using namespace std;


typedef union __attribute__ ((aligned (16))) {
        float f[4];
        __m128  v;
} __attribute__ ((aligned (16))) V4SF;

/** 
 * @brief sse matrix mutiplication a*b->c, 16bit aligned
 * 
 * @param A a
 * @param TB b, column storage priority
 * @param C c
 * @param m the row of a
 * @param n the col of b
 * @param k the col of b
 * 
 * @return 0 
 */
int SSEMatrixMul(float *A, float *TB, float *C, int m, int n, int k) {
    V4SF rc;
    __m128 r;
    for (int i = 0; i < m; i++) {
        __m128 *left = (__m128 *)(A + i*k);
        for (int j = 0; j < n; j++) {
            __m128 *right = (__m128 *)(TB + j*k);
            __m128 *tleft = left;
            rc.v = _mm_setzero_ps();

            for (int t = 0; t < k; t += 4) {
                r = _mm_mul_ps(*tleft, *right);
                rc.v = _mm_add_ps(rc.v, r);
                tleft++;
                right++;
            }
            C[i*n+j] = rc.f[0] + rc.f[1] + rc.f[2] + rc.f[3];
        }
    }

    return 0;
}



/** 
 * @brief arrange images data for convolution operation
 * 
 */
int imgMemoryPrepare(float *in, int *offsetIn, int *offsetOut, int imgNum, int imgSize, int moduleX, 
        int padding, int channels, int filterSize, int moduleStride, float *&out, int &outRow, int &outCol) {
    int exSize, filterRowLength;
    exSize = ((imgSize + 2 * padding + 3)>>2)<<2;
    filterRowLength = filterSize * filterSize * channels;

    float *inbuf = (float *)memalign(16, exSize*exSize*channels*sizeof(float));
    memset(inbuf, 0, exSize*exSize*channels*sizeof(float));

    float *outbuf = (float *)memalign(16, imgNum*moduleX*moduleX*filterRowLength*sizeof(float));
    for (int i = 0; i < imgNum; i++) {

        float *inTmp = in + i * imgSize * imgSize * channels;
        
        for (int j = 0; j < imgSize; j++) {
            memcpy(inbuf+((j+padding)*exSize+padding)*channels, inTmp+j*imgSize*channels, imgSize*channels*sizeof(float));
        }

        float *outbufTmp = outbuf + i * moduleX * moduleX * filterRowLength;
        for (int i = 0; i < moduleX * moduleX * filterSize; i++) {
            memcpy(outbufTmp+offsetOut[i], inbuf+offsetIn[i], filterSize*channels*sizeof(float));
        }
    }

    out = outbuf;
    outRow = imgNum * moduleX * moduleX;
    outCol = filterRowLength;

    free(inbuf);
    inbuf = NULL;

    return 0;
}

/** 
 * @brief convolution operation
 * 
 * @param images input images
 * @param filters the convolution kernel
 * @param targets result
 * @param offsetIn offset for arrange input images to more suitable data structure
 * @param offsetOut offset for arrage input images to more suitable data structure
 * @param imgSizeX the size of image
 * @param numModulesX the size of convolution output
 * @param paddingStart the padding start, < 0
 * @param moduleStride the distance between successive convolution applications
 * @param numImgColors the channels of input images 
 * @param scaleTargets
 * @param scaleOutput
 */
void convFilterActsUnroll(Matrix& images, Matrix& filters, Matrix& targets, int *offsetIn, int *offsetOut, 
                   int imgSizeX, int numModulesX, int paddingStart, int moduleStride, int numImgColors, 
                   float scaleTargets, float scaleOutput) {
    int numFilterColors = numImgColors;      
    int numFilters = filters.getNumRows();
    int numModules = numModulesX * numModulesX;
    int numImages = images.getNumRows();
    int imgPixels = images.getNumCols() / numImgColors;

    assert((numImgColors > 0 && (numImgColors <= 3 || numImgColors % 8 == 0)));
    assert((numFilters % 8) == 0);
    assert(images.getNumCols() == imgPixels * numImgColors);
    assert(imgSizeX * imgSizeX == imgPixels);

    int filterPixels = filters.getNumCols() / numFilterColors;
    int filterSize = int(sqrt(filterPixels));
    int filtersCols = filters.getNumCols();
    assert(filterSize * filterSize == filterPixels);
    assert(filtersCols == numFilterColors * filterPixels);

    assert(paddingStart <= 0);
    assert(paddingStart + (numModulesX-1)*moduleStride + filterSize >= imgSizeX);
    assert(moduleStride <= filterSize);
    assert(!images.isTrans());
    assert(!filters.isTrans());

    if (scaleTargets == 0) {
        targets.resize(numImages, numFilters * numModules);
    }
    float *imgData = images.getData();
    float *filterData = filters.getData();
    float *targetData = targets.getData();

    if (scaleTargets == 0) {
        memset(targetData, 0, sizeof(float) * numImages * numFilters * numModules);
    }

    int padding = -paddingStart;
    float *prepareModule = NULL;
    int prepareModuleRow = 0, prepareModuleCol = 0;

    imgMemoryPrepare(imgData, offsetIn, offsetOut, numImages, imgSizeX, numModulesX, padding, numImgColors, filterSize, 
            moduleStride, prepareModule, prepareModuleRow, prepareModuleCol);
    float *targetTmp = (float *)memalign(16, numFilters * prepareModuleRow * sizeof(float));
    cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasTrans, numFilters, prepareModuleRow, prepareModuleCol, 
            1, filterData, filtersCols, prepareModule, prepareModuleCol, 0, targetTmp, prepareModuleRow);

    if (scaleOutput != 1) {
        __m128 a, b;
        float *targetTmpPtr = targetTmp;
        b = _mm_set1_ps(scaleOutput);
        for (int i = 0; i < numFilters * prepareModuleRow; i+=8) {
            a = _mm_load_ps(targetTmpPtr);
            a = _mm_mul_ps(a, b);
            _mm_store_ps(targetTmpPtr, a);
            targetTmpPtr += 4;

            a = _mm_load_ps(targetTmpPtr);
            a = _mm_mul_ps(a, b);
            _mm_store_ps(targetTmpPtr, a);
            targetTmpPtr += 4;
        }
    }
    for (int i = 0; i < numFilters; i++) {
        for (int j = 0; j < prepareModuleRow; j++) {
            targetData[j*numFilters+i] += targetTmp[i*prepareModuleRow+j];
        }
    }


    free(targetTmp);
    targetTmp = NULL;
    free(prepareModule);
    prepareModule = NULL;
}

/** 
 * @brief make max-pooling operation for images
 * 
 * @param images the input images
 * @param targets the output targets, allocate memory within function
 * @param numFilters the num of filters
 * @param subsX the width of region for pooling
 * @param startX the x-coordinate in the input image to start the pooling
 * @param strideX the distance between successive pooling applications 
 * @param outputsX the output values in the x (equivalently, y) dimension this operation will produce
 */
void convLocalPoolMax(Matrix& images, Matrix& targets, int numFilters,
                   int subsX, int startX, int strideX, int outputsX) {


    int numImages = images.getNumRows();
    int imgPixels = images.getNumCols() / numFilters;
    assert(images.getNumCols() == numFilters * imgPixels);
    int imgSize = int(sqrt(imgPixels));
    assert(imgSize * imgSize == imgPixels);
    assert(numFilters % 8 == 0);
    assert(!images.isTrans());

    int outputs = outputsX * outputsX;
    targets.resize(numImages, numFilters*outputs);

    float *imgData = images.getData();
    float *targetData = targets.getData();

    __m128 a, b;
    int startL, startT, startR, startB;
    float *targetPtr = NULL, *imgPtr = NULL;
    for (int i = 0; i < numImages; i++) {
        targetPtr = targetData+ i * numFilters * outputs;
        imgPtr = imgData + i * numFilters * imgPixels;
        startL = startX; startT = startX; startR = startX + subsX; startB = startX + subsX;

        for (int j = 0; j < outputsX; j++) {
            for (int k = 0; k < outputsX; k++) {
                for (int l = 0; l < numFilters; l+=4) {

                    a = _mm_set1_ps(-2e38);
                    for (int m = startT; m < startB; m++) {
                        for (int n = startL; n < startR; n++) {
                            b = _mm_loadu_ps(imgPtr+(m*imgSize+n)*numFilters+l);
                            a = _mm_max_ps(a, b);
                        }
                    }
                    _mm_storeu_ps(targetPtr+(j*outputsX+k)*numFilters+l, a);
                }
                startL += strideX;
                startR += strideX;
            }
            startT += strideX;
            startB += strideX;
            startL = startX;
            startR = startX + subsX;
        }
    }
}


/** 
 * @brief make avg-pooling operation for images, note:this is a original version, incompatible with the current data structure
 * 
 * @param images the input images
 * @param targets the output targets, allocate memory within function
 * @param numFilters the num of filters
 * @param subsX the width of region for pooling
 * @param startX the x-coordinate in the input image to start the pooling
 * @param strideX the distance between successive pooling applications 
 * @param outputsX the output values in the x (equivalently, y) dimension this operation will produce
 */
void convLocalPoolAvg(Matrix& images, Matrix& targets, int numFilters,
                   int subsX, int startX, int strideX, int outputsX) {
    int numImages = images.getNumRows();
    int imgPixels = images.getNumCols() / numFilters;
    assert(images.getNumCols() == numFilters * imgPixels);
    int imgSize = int(sqrt(imgPixels));
    assert(imgSize * imgSize == imgPixels);
    assert(numFilters % 8 == 0);
    assert(!images.isTrans());

    int outputs = outputsX * outputsX;
    targets.resize(numImages, numFilters*outputs);

    float *imgData = images.getData();
    float *targetData = targets.getData();
    // integral image
    int exSize = imgSize + 1;
    int regionSize = subsX * subsX; 
    float *integralData = new float[exSize*exSize];
    float *targetPtr = NULL, *imgPtr = NULL, *integralPtr = NULL, *top = NULL, *left = NULL, *lefttop = NULL;
    for (int i = 0; i < numImages; i++) {
        for (int j = 0; j < numFilters; j++) {

            targetPtr = targetData+ i * numFilters * outputs + j * outputs;
            imgPtr = imgData + i * numFilters * imgPixels + j * imgPixels;

            memset(integralData, 0, imgPixels * sizeof(float));
            // compute integral image
            for (int m = 1; m <= imgSize; m++) {
                integralPtr = integralData + m * exSize + 1;
                top = integralPtr - exSize;
                left = integralPtr - 1;
                lefttop = top - 1;
                for (int n = 0; n < imgSize; n++) {
                    integralPtr[n] = *top++ + *left++ - *lefttop++ + imgPtr[(m-1)*imgSize+n]; 
                }
            }

            int startL, startT, startR, startB;
            startL = startX, startT = startX, startR = startX + subsX,  startB = startX + subsX;
            
            for (int m = 0; m < outputsX; m++) {
                for (int n = 0; n < outputsX; n++) {
                    targetPtr[m*outputsX+n] = (integralData[startB*exSize+startR] - integralData[startB*exSize+startL] \
                        - integralData[startT*exSize+startR] + integralData[startT*exSize+startL]) / (float)regionSize;
                    startL += strideX;
                    startR += strideX;
                }
                startT += strideX;
                startB += strideX;
                startL = startX;
                startR = startX + subsX;
            }
        }
    }

    delete []integralData;
    integralData = NULL;
        
}

/** 
 * @brief constrast normalization within single channels, note:this is a original version, incompatible with the current data structure
 * 
 * @param images the input images
 * @param meanDiffs images - mean(images), winSize is sizeX
 * @param targets the output targets, allocate memory within function 
 * @param numFilters the num of filters
 * @param sizeX the width of win for normalize
 * @param addScale 
 * @param powScale
 */
void convContrastNorm(Matrix& images, Matrix& meanDiffs, Matrix& targets, int numFilters, int sizeX, float addScale, float powScale) {
    int numImages = images.getNumRows();
    int imgPixels = images.getNumCols() / numFilters;
    assert(images.getNumCols() == numFilters * imgPixels);
    int imgSize = int(sqrt(imgPixels));
    int halfSize = sizeX / 2;
    assert(imgSize * imgSize == imgPixels);
    assert(meanDiffs.isSameDims(images));
    assert(numFilters % 8 == 0);
    assert(!images.isTrans());
    assert(!meanDiffs.isTrans());

    targets.resize(images);

    float *imgData = images.getData();
    float *diffData = meanDiffs.getData();
    float *targetData = targets.getData();

    int exSize = imgSize+1;
    float *integralData = (float *)malloc(exSize*exSize*sizeof(float));

    float *targetPtr = NULL, *imgPtr = NULL, *diffPtr = NULL, *integralPtr = NULL, *top = NULL, *left = NULL, *lefttop = NULL;
    for (int i = 0; i < numImages; i++) {
        for (int j = 0; j < numFilters; j++) {

            targetPtr = targetData+ i * numFilters * imgPixels + j * imgPixels;
            imgPtr = imgData + i * numFilters * imgPixels + j * imgPixels;
            diffPtr = diffData + i * numFilters * imgPixels + j * imgPixels;

            memset(integralData, 0, exSize * exSize * sizeof(float));
            // compute integral image
            for (int m = 1; m <= imgSize; m++) {
                integralPtr = integralData + m * exSize + 1;
                top = integralPtr - exSize;
                left = integralPtr - 1;
                lefttop = top - 1;
                for (int n = 0; n < imgSize; n++) {
                    integralPtr[n] = *top++ + *left++ - *lefttop++ + _square(diffPtr[(m-1)*imgSize+n]); 
                }
            }

            int startL, startT, startR, startB;
            for (int m = 0; m < imgSize; m++) {
                for (int n = 0; n < imgSize; n++) {
                    startL = _max(0, m-halfSize);
                    startR = _min(imgSize, m-halfSize+sizeX);
                    startT = _max(0, n-halfSize);
                    startB = _min(imgSize, n-halfSize+sizeX);
                    targetPtr[m*imgSize+n] = _pow(1.0f+addScale*(integralData[startB*exSize+startR] 
                                - integralData[startB*exSize+startL] - integralData[startT*exSize+startR] 
                                + integralData[startT*exSize+startL]), -powScale) * imgPtr[m*imgSize+n];
                }
            }
        }
    }

    free(integralData);
    integralData = NULL;
}

void convResponseNorm(Matrix& images, Matrix& targets, int numFilters, int sizeX, float addScale, float powScale) {
    convContrastNorm(images, images, targets, numFilters, sizeX, addScale, powScale);
}


/** 
 * @brief constrast normalization cross channels
 * 
 * @param images the input images
 * @param meanDiffs images - mean(images), winSize is sizeX
 * @param targets the output targets, allocate memory within function 
 * @param numFilters the num of filters
 * @param sizeF the width of win for normalize
 * @param addScale 
 * @param powScale
 */
void convContrastNormCrossMap(Matrix& images, Matrix& meanDiffs, Matrix& targets, int numFilters, 
        int sizeF, float addScale, float powScale) {
    int numImages = images.getNumRows();
    int imgPixels = images.getNumCols() / numFilters;
    int numCols = images.getNumCols();
    assert(numCols == numFilters * imgPixels);
    int imgSize = int(sqrt(imgPixels));
    int halfSize = sizeF / 2;
    assert(imgSize * imgSize == imgPixels);
    assert(meanDiffs.isSameDims(images));
    assert(numFilters % 8 == 0);
    assert(!images.isTrans());
    assert(!meanDiffs.isTrans());

    targets.resize(images);
    float *imgData = images.getData();
    float *diffData = meanDiffs.getData();
    float *targetData = targets.getData();
    float *integralData = (float *)memalign(16, (numFilters+sizeF+1) * sizeof(float));
    for (int i = 0; i <= halfSize; i++) {
        integralData[i] = 0;
    }
    float *targetPtr = NULL, *imgPtr = NULL, *diffPtr = NULL;

    __m128 a, b, scale;
    scale = _mm_set1_ps(addScale);
    for (int i = 0; i < numImages; i++) {

        targetPtr = targetData + i * numCols;
        imgPtr = imgData + i * numCols;
        diffPtr = diffData + i * numCols;

        for (int m = 0; m < imgSize; m++) {
            for (int n = 0; n < imgSize; n++) {
                for (int k = 0; k < numFilters; k++) {
                    integralData[k+halfSize+1] = integralData[k+halfSize] + _square(*diffPtr++);
                }
                for (int k = numFilters+halfSize+1; k <= numFilters+sizeF; k++) {
                    integralData[k] = integralData[numFilters+halfSize];
                }
                for (int k = 0; k < numFilters; k+=4) {

                    a = _mm_load_ps(integralData+k);
                    b = _mm_loadu_ps(integralData+k+sizeF);
                    a = _mm_sub_ps(b, a);
                    a = _mm_mul_ps(a, scale);
                    a = _mm_add_ps(a, _mm_set1_ps(1.0));

                    b = _mm_mul_ps(a, a);
                    a = _mm_mul_ps(b, a);
                    a = _mm_div_ps(_mm_set1_ps(1.0), _mm_sqrt_ps(_mm_sqrt_ps(a)));
                    b = _mm_load_ps(imgPtr);
                    a = _mm_mul_ps(a, b);
                    _mm_storeu_ps(targetPtr, a);

                    imgPtr += 4;
                    targetPtr += 4;
                }
            }
        }
    }

    free(integralData);
    integralData = NULL;
}


void convResponseNormCrossMap(Matrix& images, Matrix& targets, int numFilters, int sizeF, float addScale, float powScale) {
    convContrastNormCrossMap(images, images, targets, numFilters, sizeF, addScale, powScale);
}

void convAddBiases(Matrix& biases, Matrix& targets, int numModules, bool sharedBiases) {
    int numImages = targets.getNumRows();
    int numFilters = targets.getNumCols() / numModules;
    assert(numFilters % 8 == 0);
    assert(targets.getNumCols() == numFilters * numModules);
    assert((sharedBiases && biases.getNumCols() == numFilters) || 
            (!sharedBiases && biases.getNumCols() == numFilters * numModules));
    assert(!biases.isTrans());
    assert(!targets.isTrans());

    float *biasesData = biases.getData();
    float *targetData = targets.getData();
    float *biasesPtr = NULL;

    __m128 a, b;
    if (sharedBiases) {
        for (int i = 0; i < numImages; i++) {
            for (int j = 0; j < numModules; j++) {
                biasesPtr = biasesData;
                for (int k = 0; k < numFilters; k+=4) {
                    a = _mm_loadu_ps(targetData);
                    b = _mm_loadu_ps(biasesPtr);

                    a = _mm_add_ps(a, b);
                    _mm_storeu_ps(targetData, a);
                    targetData += 4;
                    biasesPtr += 4;
                }
            }
        }
    } else {
        for (int i = 0; i < numImages; i++) {
            biasesPtr = biasesData;
            for (int j = 0; j < numFilters * numModules; j+=4) {
                a = _mm_loadu_ps(targetData);
                b = _mm_loadu_ps(biasesPtr);

                a = _mm_add_ps(a, b);
                _mm_storeu_ps(targetData, a);
                targetData += 4;
                biasesData += 4;
            }
        }
    }
}

void fcAddBiases(Matrix& biases, Matrix& targets) {
    int numImages = targets.getNumRows();
    int biasesLen = biases.getNumCols();
    assert(biases.getNumCols() == targets.getNumCols());
    assert(!biases.isTrans());
    assert(!targets.isTrans());

    float *biasesData = biases.getData();
    float *targetData = targets.getData();
    float *biasesPtr = NULL;
    
    int alignedLen = (biasesLen >> 2) << 2;
    int leftLen = biasesLen & 3;
    __m128 a, b;
    for (int i = 0; i < numImages; i++) {
        biasesPtr = biasesData;
        for (int j = 0; j < alignedLen; j+=4) {
            a = _mm_loadu_ps(targetData);
            b = _mm_loadu_ps(biasesPtr);

            a = _mm_add_ps(a, b);
            _mm_storeu_ps(targetData, a);
            targetData += 4;
            biasesPtr += 4;
        }
        for (int j = 0; j < leftLen; j++) {
            *targetData++ = *biasesPtr++;
        }
    }
}

