 
#include <iostream>
#include <malloc.h>
#include "layer.h"
#include "util.h"
#include "conv_util.h"
#include "matrix.h"

using namespace std;

/* 
 * =======================
 * Layer
 * =======================
 */

Layer::Layer(ConvNet* convNet, dictParam_t& paramsDict) :
             _convNet(convNet){
    _name = dictGetString(paramsDict, "name");
    _type = dictGetString(paramsDict, "type");
}

Layer::~Layer() {
}

void Layer::fprop(Matrix &data, Matrix &output) {

    if (_prev[0]->getType() == "data") {
        fpropActs(data, 0, 0, output);
        return;
    }
    MatrixV &matV = *(new MatrixV);
    for (int i = 0; i < _prev.size(); i++) {
        Matrix *mat = new Matrix;
        _prev[i]->fprop(data, *mat);
        matV.push_back(mat);
    }

    for (int i = 0; i < _prev.size(); i++) {
        fpropActs(*(matV[i]), i, i > 0, output);
    }
    for (int i = 0; i < _prev.size(); i++) {
        delete matV[i];
        matV[i] = NULL;
    }
    delete &matV;
}

string& Layer::getName() {
    return _name;
}

string& Layer::getType() {
    return _type;
}

void Layer::addNext(Layer* l) {
    _next.push_back(l);
}

void Layer::addPrev(Layer* l) {
    _prev.push_back(l);
}

vector<Layer*>& Layer::getPrev() {
    return _prev;
}

vector<Layer*>& Layer::getNext() {
    return _next;
}

/* 
 * =======================
 * NeuronLayer
 * =======================
 */
NeuronLayer::NeuronLayer(ConvNet* convNet, dictParam_t& paramsDict) 
    : Layer(convNet, paramsDict) {
        _neuron = &Neuron::makeNeuron(paramsDict);
    }
NeuronLayer::~NeuronLayer() {
    if (_neuron != NULL) {
        delete _neuron;
        _neuron = NULL;
    }
}
void NeuronLayer::fpropActs(Matrix &input, int inpIdx, float scaleTargets, Matrix &output) {
    output.resize(input);
    _neuron->activate(input, output);
}

/* 
 * =======================
 * WeightLayer
 * =======================
 */
WeightLayer::WeightLayer(ConvNet* convNet, dictParam_t& paramsDict) : 
    Layer(convNet, paramsDict) {

    MatrixV& hWeights = *dictGetMatrixV(paramsDict, "weights");
    Matrix& hBiases = *dictGetMatrix(paramsDict, "biases");

    for (int i = 0; i < hWeights.size(); i++) {
        _weights.addWeights(*new Weights(*hWeights[i]));
    }
    _biases = new Weights(hBiases);

    delete &hWeights;
}

Weights& WeightLayer::getWeights(int idx) {
    return _weights[idx];
}

/* 
 * =======================
 * FCLayer
 * =======================
 */
FCLayer::FCLayer(ConvNet* convNet, dictParam_t& paramsDict) : WeightLayer(convNet, paramsDict) {
}

void FCLayer::fpropActs(Matrix &input, int inpIdx, float scaleTargets, Matrix &output) {
    output.addProduct(input, *_weights[inpIdx], 1, scaleTargets);

    if (scaleTargets == 0) {
        fcAddBiases(_biases->getW(), output);
    }
}

/* 
 * =======================
 * LocalLayer
 * =======================
 */
LocalLayer::LocalLayer(ConvNet* convNet, dictParam_t& paramsDict) 
    : WeightLayer(convNet, paramsDict) {
    _modulesX = dictGetInt(paramsDict, "modulesX");
    _numFilters = dictGetInt(paramsDict, "filters");
    _channels = dictGetIntV(paramsDict, "channels");
    _imgSize = dictGetIntV(paramsDict, "imgSize");
    _filterChannels = dictGetIntV(paramsDict, "filterChannels");
    _filterSize = dictGetIntV(paramsDict, "filterSize");
    _padding = dictGetIntV(paramsDict, "padding");
    _stride = dictGetIntV(paramsDict, "stride");
    _groups = dictGetIntV(paramsDict, "groups");
}

/* 
 * =======================
 * ConvLayer
 * =======================
 */
ConvLayer::ConvLayer(ConvNet* convNet, dictParam_t& paramsDict) : LocalLayer(convNet, paramsDict) {
    _sharedBiases = dictGetInt(paramsDict, "sharedBiases");
    imgOffsetOut = NULL;
    imgOffsetIn = NULL;
    makeOffset();
}

ConvLayer::~ConvLayer() {
    if (imgOffsetOut != NULL) {
        for (int i = 0; i < _filterSize->size(); i++) {
            free(imgOffsetOut[i]);
        }
        free(imgOffsetOut);
        imgOffsetOut = NULL;
    }
    if (imgOffsetIn != NULL) {
        for (int i = 0; i < _filterSize->size(); i++) {
            free(imgOffsetIn[i]);
        }
        free(imgOffsetIn);
        imgOffsetIn = NULL;
    }
}
void ConvLayer::makeOffset() {
    imgOffsetOut = (int **)malloc(sizeof(int *) * _filterSize->size());
    imgOffsetIn = (int **)malloc(sizeof(int *) * _filterSize->size());
    for (int inpIdx = 0; inpIdx < _filterSize->size(); inpIdx++) {
        int moduleX = _modulesX;
        int filterSize = _filterSize->at(inpIdx);
        int channels = _channels->at(inpIdx);
        int moduleStride = _stride->at(inpIdx);
        int filterRowLength = filterSize * filterSize * channels;
        int padding = -_padding->at(inpIdx);
        int exSize = _imgSize->at(inpIdx) + 2 * padding;
        exSize = ((exSize + 3)>>2)<<2;
        imgOffsetOut[inpIdx] = (int *)memalign(16, moduleX * moduleX * filterSize * sizeof(int));                              
        imgOffsetIn[inpIdx] = (int *)memalign(16, moduleX * moduleX * filterSize * sizeof(int));
        for (int i = 0; i < moduleX; i++) {                                                                         
            for (int j = 0; j < moduleX; j++) {                                                                     
                for (int k = 0; k < filterSize; k++) {                                                              
                    imgOffsetOut[inpIdx][(i*moduleX+j)*filterSize+k] = (i*moduleX+j)*filterRowLength + k*filterSize * channels;
                    imgOffsetIn[inpIdx][(i*moduleX+j)*filterSize+k] = ((i*moduleStride+k)*exSize + j*moduleStride) * channels; 
                }                                                                                                   
            }                                                                                                       
        }                                       
    }
}

void ConvLayer::fpropActs(Matrix &input, int inpIdx, float scaleTargets, Matrix &output) {
    convFilterActsUnroll(input, *_weights[inpIdx], output, imgOffsetIn[inpIdx], imgOffsetOut[inpIdx], 
            _imgSize->at(inpIdx), _modulesX,_padding->at(inpIdx), _stride->at(inpIdx), _channels->at(inpIdx), 
            scaleTargets, 1);

    if (scaleTargets == 0) {
        convAddBiases(_biases->getW(), output, _modulesX * _modulesX, _sharedBiases);
    }
}

/* 
 * =======================
 * SoftmaxLayer
 * =======================
 */
SoftmaxLayer::SoftmaxLayer(ConvNet* convNet, dictParam_t &paramsDict) : Layer(convNet, paramsDict) {
    _labelsDim = dictGetInt(paramsDict, "outputs");
}

void SoftmaxLayer::fpropActs(Matrix &input, int inpIdx, float scaleTargets, Matrix &output) {
    
    Matrix& max = input.max(1);
    
    input.addVector(max, -1, output);
    
    output.apply(Matrix::EXP);
    Matrix& sum = output.sum(1);
    output.eltwiseDivideByVector(sum);

    delete &max;
    delete &sum;
}

/* 
 * =======================
 * DataLayer
 * =======================
 */
DataLayer::DataLayer(ConvNet* convNet, dictParam_t& paramsDict) : Layer(convNet, paramsDict) {
    _inputDim = dictGetInt(paramsDict, "dataDim");
}

void DataLayer::fpropActs(Matrix &input, int inpIdx, float scaleTargets, Matrix &output) {
    output = input;    
}
/* 
 * =====================
 * PoolLayer
 * =====================
 */
PoolLayer::PoolLayer(ConvNet* convNet, dictParam_t& paramsDict) 
    : Layer(convNet, paramsDict) {
    _pool = dictGetString(paramsDict, "pool");
    _channels = dictGetInt(paramsDict, "channels");
    _sizeX = dictGetInt(paramsDict, "sizeX");
    _start = dictGetInt(paramsDict, "start");
    _stride = dictGetInt(paramsDict, "stride");
    _outputsX = dictGetInt(paramsDict, "outputsX");
    _imgSize = dictGetInt(paramsDict, "imgSize");
}

PoolLayer& PoolLayer::makePoolLayer(ConvNet* convNet, dictParam_t& paramsDict) {
    string _pool = dictGetString(paramsDict, "pool");
    if (_pool == "max") {
        return *new MaxPoolLayer(convNet, paramsDict);
    } else if(_pool == "avg") {
        return *new AvgPoolLayer(convNet, paramsDict);
    }
    throw string("Unknown pooling layer type ") + _pool;
}

/* 
 * =====================
 * AvgPoolLayer
 * =====================
 */
AvgPoolLayer::AvgPoolLayer(ConvNet* convNet, dictParam_t& paramsDict) : PoolLayer(convNet, paramsDict) {
}

void AvgPoolLayer::fpropActs(Matrix &input, int inpIdx, float scaleTargets, Matrix &output) {
    convLocalPoolAvg(input, output, _channels, _sizeX, _start, _stride, _outputsX);
}


/* 
 * =====================
 * MaxPoolLayer
 * =====================
 */
MaxPoolLayer::MaxPoolLayer(ConvNet* convNet, dictParam_t& paramsDict) : PoolLayer(convNet, paramsDict) {
}

void MaxPoolLayer::fpropActs(Matrix &input, int inpIdx, float scaleTargets, Matrix &output) {
    convLocalPoolMax(input, output, _channels, _sizeX, _start, _stride, _outputsX);
}

/* 
 * =====================
 * ResponseNormLayer
 * =====================
 */
ResponseNormLayer::ResponseNormLayer(ConvNet* convNet, dictParam_t& paramsDict) : Layer(convNet, paramsDict) {
    _channels = dictGetInt(paramsDict, "channels");
    _size = dictGetInt(paramsDict, "size");

    _scale = dictGetFloat(paramsDict, "scale");
    _pow = dictGetFloat(paramsDict, "pow");
}

void ResponseNormLayer::fpropActs(Matrix &input, int inpIdx, float scaleTargets, Matrix &output) {
    convResponseNorm(input, output, _channels, _size, _scale, _pow);
}

/* 
 * =====================
 * CrossMapResponseNormLayer
 * =====================
 */
CrossMapResponseNormLayer::CrossMapResponseNormLayer(ConvNet* convNet, dictParam_t& paramsDict) : ResponseNormLayer(convNet, paramsDict) {
    _imgSize = dictGetInt(paramsDict, "imgSize");
}

void CrossMapResponseNormLayer::fpropActs(Matrix &input, int inpIdx, float scaleTargets, Matrix &output) {
    convResponseNormCrossMap(input, output, _channels, _size, _scale, _pow);
}



/* 
 * =====================
 * ContrastNormLayer
 * =====================
 */
ContrastNormLayer::ContrastNormLayer(ConvNet* convNet, dictParam_t& paramsDict) : ResponseNormLayer(convNet, paramsDict) {
    _imgSize = dictGetInt(paramsDict, "imgSize");
}

void ContrastNormLayer::fpropActs(Matrix &input, int inpIdx, float scaleTargets, Matrix &output) {
    Matrix meanDiffs;
    convLocalPoolAvg(input, meanDiffs, _channels, _size, 0, 1, _imgSize);
    meanDiffs.subtract(input);
    convContrastNorm(input, meanDiffs, output, _channels, _size, _scale, _pow);
}

