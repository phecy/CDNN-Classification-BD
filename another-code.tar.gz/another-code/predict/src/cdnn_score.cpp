#include <assert.h>
#include <vector>
#include <malloc.h>
#include "matrix.h"
#include "util.h"
#include "convnet.h"

using namespace std;

static ConvNet* model = NULL;

int initModel(const char *filePath) {
    
    assert(model == NULL);

    listDictParam_t layerParams;
    if (loadParam(filePath, layerParams) == -1) {
        return -1;
    }

    model = new ConvNet(layerParams);

    releaseParam(); 

    if (model != NULL) {
        return 0;
    } else {
        return -1;
    }
}

int cnnScore(float *data, int dataNum, int dataDim, float *probs) {
    assert(model != NULL);
    assert(dataDim == (model->getLayer(0))->getDataDim());
    Matrix dataMat(data, dataNum, dataDim);
    Matrix probsMat;

    model->cnnScore(dataMat, probsMat);

    memcpy(probs, probsMat.getData(), probsMat.getNumElements() * sizeof(float));
    return 0;
}

int releaseModel() {
    if (model != NULL) {
        delete model;
        model = NULL;
    }
    return 0;
}

int getDataDim() {
    return (model->getLayer(0))->getDataDim();
}

int getLabelsDim() {
    
    int numLayers = model->getNumLayers();
    return (model->getLayer(numLayers-1))->getLabelsDim();

}



